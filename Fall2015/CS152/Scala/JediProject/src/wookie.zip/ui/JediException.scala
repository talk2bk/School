package ui

/**
 * @author CuTs
 */
class JediException(val msg: String = "Your force is weak") extends Exception(msg){
  
}