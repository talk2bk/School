package values
import java.io.Serializable

trait Value extends Serializable{
}