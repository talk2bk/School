package expression

/**
 * @author CuTs
 */
trait SpecialForm extends Expression{

}